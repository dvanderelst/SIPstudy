# Step Counts Statistics

## Linear Model Results

### Linear Model Results for Bernie

```
                            OLS Regression Results                            
==============================================================================
Dep. Variable:                  steps   R-squared:                       0.352
Model:                            OLS   Adj. R-squared:                  0.340
Method:                 Least Squares   F-statistic:                     30.41
Date:                Fri, 05 Sep 2025   Prob (F-statistic):           9.23e-07
Time:                        13:15:16   Log-Likelihood:                -120.19
No. Observations:                  58   AIC:                             244.4
Df Residuals:                      56   BIC:                             248.5
Df Model:                           1                                         
Covariance Type:            nonrobust                                         
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept      4.7564      0.476     10.001      0.000       3.804       5.709
Days           0.0544      0.010      5.515      0.000       0.035       0.074
==============================================================================
Omnibus:                        0.593   Durbin-Watson:                   1.952
Prob(Omnibus):                  0.743   Jarque-Bera (JB):                0.664
Skew:                           0.223   Prob(JB):                        0.717
Kurtosis:                       2.724   Cond. No.                         89.2
==============================================================================

Notes:
[1] Standard Errors assume correct specification of covariance matrix.
```

### Linear Model Results for Citrine

```
                            OLS Regression Results                            
==============================================================================
Dep. Variable:                  steps   R-squared:                       0.072
Model:                            OLS   Adj. R-squared:                  0.054
Method:                 Least Squares   F-statistic:                     3.895
Date:                Fri, 05 Sep 2025   Prob (F-statistic):             0.0540
Time:                        13:15:16   Log-Likelihood:                -150.25
No. Observations:                  52   AIC:                             304.5
Df Residuals:                      50   BIC:                             308.4
Df Model:                           1                                         
Covariance Type:            nonrobust                                         
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept     16.9085      1.161     14.557      0.000      14.576      19.241
Days          -0.0498      0.025     -1.973      0.054      -0.101       0.001
==============================================================================
Omnibus:                        0.695   Durbin-Watson:                   1.574
Prob(Omnibus):                  0.706   Jarque-Bera (JB):                0.522
Skew:                           0.242   Prob(JB):                        0.770
Kurtosis:                       2.922   Cond. No.                         86.9
==============================================================================

Notes:
[1] Standard Errors assume correct specification of covariance matrix.
```

### Linear Model Results for Elia

```
                            OLS Regression Results                            
==============================================================================
Dep. Variable:                  steps   R-squared:                       0.017
Model:                            OLS   Adj. R-squared:                  0.001
Method:                 Least Squares   F-statistic:                     1.054
Date:                Fri, 05 Sep 2025   Prob (F-statistic):              0.309
Time:                        13:15:16   Log-Likelihood:                -70.141
No. Observations:                  62   AIC:                             144.3
Df Residuals:                      60   BIC:                             148.5
Df Model:                           1                                         
Covariance Type:            nonrobust                                         
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept      2.0513      0.179     11.491      0.000       1.694       2.408
Days           0.0035      0.003      1.027      0.309      -0.003       0.010
==============================================================================
Omnibus:                        1.439   Durbin-Watson:                   1.441
Prob(Omnibus):                  0.487   Jarque-Bera (JB):                0.955
Skew:                           0.297   Prob(JB):                        0.620
Kurtosis:                       3.133   Cond. No.                         95.2
==============================================================================

Notes:
[1] Standard Errors assume correct specification of covariance matrix.
```

### Linear Model Results for Minerva

```
                            OLS Regression Results                            
==============================================================================
Dep. Variable:                  steps   R-squared:                       0.001
Model:                            OLS   Adj. R-squared:                 -0.018
Method:                 Least Squares   F-statistic:                   0.04356
Date:                Fri, 05 Sep 2025   Prob (F-statistic):              0.835
Time:                        13:15:16   Log-Likelihood:                -76.059
No. Observations:                  54   AIC:                             156.1
Df Residuals:                      52   BIC:                             160.1
Df Model:                           1                                         
Covariance Type:            nonrobust                                         
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept      2.8276      0.286      9.881      0.000       2.253       3.402
Days           0.0012      0.006      0.209      0.835      -0.010       0.012
==============================================================================
Omnibus:                        1.117   Durbin-Watson:                   1.136
Prob(Omnibus):                  0.572   Jarque-Bera (JB):                1.170
Skew:                          -0.292   Prob(JB):                        0.557
Kurtosis:                       2.578   Cond. No.                         106.
==============================================================================

Notes:
[1] Standard Errors assume correct specification of covariance matrix.
```

## Kolmogorov–Smirnov Tests

| Subject   | Comparison                | KS statistics   | p-value   |
|:----------|:--------------------------|:----------------|:----------|
| Bernie    | interval 60s vs Baseline  | ks = 0.283      | p = 0.763 |
| Bernie    | interval 120s vs Baseline | ks = 0.351      | p = 0.415 |
| Bernie    | interval 180s vs Baseline | ks = 0.497      | p = 0.147 |
| Bernie    | interval 240s vs Baseline | ks = 0.210      | p = 0.955 |
| Bernie    | interval 300s vs Baseline | ks = 0.645      | p = 0.023 |
| Citrine   | interval 60s vs Baseline  | ks = 0.500      | p = 0.563 |
| Citrine   | interval 120s vs Baseline | ks = 0.808      | p = 0.005 |
| Citrine   | interval 180s vs Baseline | ks = 0.519      | p = 0.119 |
| Citrine   | interval 240s vs Baseline | ks = 0.481      | p = 0.178 |
| Citrine   | interval 300s vs Baseline | ks = 0.246      | p = 0.884 |
| Elia      | interval 60s vs Baseline  | ks = 0.355      | p = 0.499 |
| Elia      | interval 120s vs Baseline | ks = 0.452      | p = 0.228 |
| Elia      | interval 180s vs Baseline | ks = 0.290      | p = 0.739 |
| Elia      | interval 240s vs Baseline | ks = 0.639      | p = 0.025 |
| Elia      | interval 300s vs Baseline | ks = 0.439      | p = 0.250 |
| Minerva   | interval 60s vs Baseline  | ks = 0.226      | p = 0.929 |
| Minerva   | interval 120s vs Baseline | ks = 0.296      | p = 0.728 |
| Minerva   | interval 180s vs Baseline | ks = 0.630      | p = 0.031 |
| Minerva   | interval 240s vs Baseline | ks = 0.389      | p = 0.396 |
| Minerva   | interval 300s vs Baseline | ks = 0.630      | p = 0.031 |

# Activity Pattern Statistics

## Activity Pattern Results for 60 Interval

### Logistic Generalized Linear Model, 60s, First 2/3s of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:                 Active   No. Observations:                  488
Model:                          Logit   Df Residuals:                      484
Method:                           MLE   Df Model:                            3
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                 0.04769
Time:                        13:15:16   Log-Likelihood:                -288.26
converged:                       True   LL-Null:                       -302.69
Covariance Type:            nonrobust   LLR p-value:                 2.387e-06
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept             0.4877      0.351      1.390      0.164      -0.200       1.175
Subject = Elia       -1.1217      0.247     -4.533      0.000      -1.607      -0.637
Subject = Minerva    -1.0771      0.248     -4.341      0.000      -1.563      -0.591
TimeSinceFeeding     -0.0231      0.013     -1.708      0.088      -0.050       0.003
=====================================================================================
```

### Logistic Generalized Linear Model, 60s, Last 1/3 of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:                 Active   No. Observations:                  487
Model:                          Logit   Df Residuals:                      483
Method:                           MLE   Df Model:                            3
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                 0.03339
Time:                        13:15:16   Log-Likelihood:                -303.90
converged:                       True   LL-Null:                       -314.40
Covariance Type:            nonrobust   LLR p-value:                 0.0001056
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept            -2.6132      0.714     -3.660      0.000      -4.012      -1.214
Subject = Elia       -0.5354      0.241     -2.219      0.026      -1.008      -0.063
Subject = Minerva    -0.7026      0.245     -2.864      0.004      -1.183      -0.222
TimeSinceFeeding      0.0458      0.013      3.498      0.000       0.020       0.071
=====================================================================================
```

## Activity Pattern Results for 120 Interval

### Logistic Generalized Linear Model, 120s, First 2/3s of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:                 Active   No. Observations:                  551
Model:                          Logit   Df Residuals:                      546
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.1328
Time:                        13:15:16   Log-Likelihood:                -312.03
converged:                       True   LL-Null:                       -359.83
Covariance Type:            nonrobust   LLR p-value:                 8.516e-20
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept             0.6358      0.275      2.313      0.021       0.097       1.175
Subject = Citrine    -1.3530      0.268     -5.052      0.000      -1.878      -0.828
Subject = Elia       -2.0174      0.252     -8.020      0.000      -2.510      -1.524
Subject = Minerva    -2.2682      0.305     -7.438      0.000      -2.866      -1.670
TimeSinceFeeding      0.0027      0.005      0.575      0.566      -0.006       0.012
=====================================================================================
```

### Logistic Generalized Linear Model, 120s, Last 1/3 of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:                 Active   No. Observations:                  324
Model:                          Logit   Df Residuals:                      319
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.1456
Time:                        13:15:16   Log-Likelihood:                -187.73
converged:                       True   LL-Null:                       -219.72
Covariance Type:            nonrobust   LLR p-value:                 4.252e-13
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept            -6.8073      1.153     -5.904      0.000      -9.067      -4.547
Subject = Citrine    -1.2505      0.379     -3.303      0.001      -1.993      -0.508
Subject = Elia       -1.3703      0.333     -4.118      0.000      -2.022      -0.718
Subject = Minerva    -0.5576      0.362     -1.540      0.124      -1.267       0.152
TimeSinceFeeding      0.0683      0.011      6.298      0.000       0.047       0.090
=====================================================================================
```

## Activity Pattern Results for 180 Interval

### Logistic Generalized Linear Model, 180s, First 2/3s of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:                 Active   No. Observations:                  471
Model:                          Logit   Df Residuals:                      466
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.1733
Time:                        13:15:16   Log-Likelihood:                -239.05
converged:                       True   LL-Null:                       -289.14
Covariance Type:            nonrobust   LLR p-value:                 8.938e-21
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept             1.3888      0.304      4.575      0.000       0.794       1.984
Subject = Citrine    -1.1504      0.304     -3.781      0.000      -1.747      -0.554
Subject = Elia       -2.1627      0.317     -6.814      0.000      -2.785      -1.541
Subject = Minerva    -2.2866      0.328     -6.972      0.000      -2.929      -1.644
TimeSinceFeeding     -0.0160      0.003     -4.637      0.000      -0.023      -0.009
=====================================================================================
```

### Logistic Generalized Linear Model, 180s, Last 1/3 of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:                 Active   No. Observations:                  229
Model:                          Logit   Df Residuals:                      224
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.1054
Time:                        13:15:16   Log-Likelihood:                -136.87
converged:                       True   LL-Null:                       -153.00
Covariance Type:            nonrobust   LLR p-value:                 1.691e-06
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept            -6.4208      1.431     -4.488      0.000      -9.225      -3.617
Subject = Citrine    -1.0766      0.442     -2.433      0.015      -1.944      -0.209
Subject = Elia       -0.9195      0.384     -2.392      0.017      -1.673      -0.166
Subject = Minerva    -0.8926      0.390     -2.290      0.022      -1.656      -0.129
TimeSinceFeeding      0.0416      0.009      4.627      0.000       0.024       0.059
=====================================================================================
```

## Activity Pattern Results for 240 Interval

### Logistic Generalized Linear Model, 240s, First 2/3s of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:                 Active   No. Observations:                  531
Model:                          Logit   Df Residuals:                      526
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.1936
Time:                        13:15:16   Log-Likelihood:                -225.81
converged:                       True   LL-Null:                       -280.02
Covariance Type:            nonrobust   LLR p-value:                 1.589e-22
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept             0.6110      0.278      2.199      0.028       0.066       1.156
Subject = Citrine    -2.4003      0.373     -6.436      0.000      -3.131      -1.669
Subject = Elia       -1.4499      0.268     -5.404      0.000      -1.976      -0.924
Subject = Minerva    -3.1442      0.488     -6.437      0.000      -4.102      -2.187
TimeSinceFeeding     -0.0076      0.003     -2.756      0.006      -0.013      -0.002
=====================================================================================
```

### Logistic Generalized Linear Model, 240s, Last 1/3 of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:                 Active   No. Observations:                  280
Model:                          Logit   Df Residuals:                      275
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.1746
Time:                        13:15:16   Log-Likelihood:                -150.62
converged:                       True   LL-Null:                       -182.49
Covariance Type:            nonrobust   LLR p-value:                 4.746e-13
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept            -4.8439      1.168     -4.148      0.000      -7.133      -2.555
Subject = Citrine    -1.0072      0.363     -2.776      0.006      -1.718      -0.296
Subject = Elia       -2.2305      0.402     -5.548      0.000      -3.019      -1.443
Subject = Minerva    -1.9570      0.419     -4.675      0.000      -2.777      -1.137
TimeSinceFeeding      0.0261      0.006      4.576      0.000       0.015       0.037
=====================================================================================
```

## Activity Pattern Results for 300 Interval

### Logistic Generalized Linear Model, 300s, First 2/3s of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:                 Active   No. Observations:                  536
Model:                          Logit   Df Residuals:                      531
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                 0.09096
Time:                        13:15:16   Log-Likelihood:                -315.13
converged:                       True   LL-Null:                       -346.66
Covariance Type:            nonrobust   LLR p-value:                 6.586e-13
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept             0.8772      0.248      3.533      0.000       0.391       1.364
Subject = Citrine    -0.4818      0.263     -1.831      0.067      -0.998       0.034
Subject = Elia       -0.5221      0.242     -2.161      0.031      -0.996      -0.048
Subject = Minerva    -1.6867      0.312     -5.398      0.000      -2.299      -1.074
TimeSinceFeeding     -0.0094      0.002     -5.316      0.000      -0.013      -0.006
=====================================================================================
```

### Logistic Generalized Linear Model, 300s, Last 1/3 of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:                 Active   No. Observations:                  283
Model:                          Logit   Df Residuals:                      278
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.1142
Time:                        13:15:16   Log-Likelihood:                -162.82
converged:                       True   LL-Null:                       -183.81
Covariance Type:            nonrobust   LLR p-value:                 1.690e-08
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept            -5.2401      1.198     -4.375      0.000      -7.588      -2.892
Subject = Citrine    -0.9090      0.372     -2.442      0.015      -1.638      -0.179
Subject = Elia       -0.7684      0.342     -2.249      0.025      -1.438      -0.099
Subject = Minerva    -1.8594      0.435     -4.279      0.000      -2.711      -1.008
TimeSinceFeeding      0.0210      0.005      4.524      0.000       0.012       0.030
=====================================================================================
```

# Space Allocation Statistics

## Effect of Interval on Space Allocation

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:               AtFeeder   No. Observations:                 4180
Model:                          Logit   Df Residuals:                     4174
Method:                           MLE   Df Model:                            5
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.1881
Time:                        13:15:16   Log-Likelihood:                -1970.0
converged:                       True   LL-Null:                       -2426.4
Covariance Type:            nonrobust   LLR p-value:                4.694e-195
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept             0.4190      0.120      3.490      0.000       0.184       0.654
Subject = Citrine     0.2379      0.097      2.463      0.014       0.049       0.427
Subject = Elia        2.2132      0.114     19.440      0.000       1.990       2.436
Subject = Minerva     2.4406      0.131     18.631      0.000       2.184       2.697
Feeder_Interval      -0.0025      0.001     -4.391      0.000      -0.004      -0.001
TimeSinceFeeding     -0.0003      0.001     -0.478      0.633      -0.002       0.001
=====================================================================================
```

## Testing for Differences Between Baseline and Experimental Conditions

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:               AtFeeder   No. Observations:                 6479
Model:                          Logit   Df Residuals:                     6469
Method:                           MLE   Df Model:                            9
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.1329
Time:                        13:15:16   Log-Likelihood:                -3679.8
converged:                       True   LL-Null:                       -4244.1
Covariance Type:            nonrobust   LLR p-value:                3.310e-237
=========================================================================================
                            coef    std err          z      P>|z|      [0.025      0.975]
-----------------------------------------------------------------------------------------
Intercept                -0.5430      0.056     -9.626      0.000      -0.654      -0.432
Subject = Citrine        -0.2339      0.076     -3.089      0.002      -0.382      -0.085
Subject = Elia            1.0726      0.079     13.653      0.000       0.919       1.227
Subject = Minerva         1.2707      0.083     15.334      0.000       1.108       1.433
Feeder_Interval = 60      1.8377      0.114     16.121      0.000       1.614       2.061
Feeder_Interval = 120     0.9389      0.098      9.541      0.000       0.746       1.132
Feeder_Interval = 180     1.0078      0.115      8.796      0.000       0.783       1.232
Feeder_Interval = 240     0.9202      0.119      7.747      0.000       0.687       1.153
Feeder_Interval = 300     0.7657      0.131      5.838      0.000       0.509       1.023
TimeSinceFeeding         -0.0003      0.001     -0.463      0.644      -0.001       0.001
=========================================================================================
```

## Location results for 60 interval

### Logistic Generalized Linear Model, 60s, First 2/3s of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:               AtFeeder   No. Observations:                  488
Model:                          Logit   Df Residuals:                      484
Method:                           MLE   Df Model:                            3
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                 0.04302
Time:                        13:15:16   Log-Likelihood:                -177.81
converged:                       True   LL-Null:                       -185.80
Covariance Type:            nonrobust   LLR p-value:                  0.001141
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept             1.4565      0.471      3.094      0.002       0.534       2.379
Subject = Elia        1.0688      0.329      3.248      0.001       0.424       1.714
Subject = Minerva     1.1694      0.341      3.429      0.001       0.501       1.838
TimeSinceFeeding     -0.0111      0.018     -0.603      0.547      -0.047       0.025
=====================================================================================
```

### Logistic Generalized Linear Model, 60s, Last 1/3 of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:               AtFeeder   No. Observations:                  487
Model:                          Logit   Df Residuals:                      483
Method:                           MLE   Df Model:                            3
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.1249
Time:                        13:15:16   Log-Likelihood:                -162.47
converged:                       True   LL-Null:                       -185.66
Covariance Type:            nonrobust   LLR p-value:                 4.669e-10
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept            -0.4107      1.021     -0.402      0.688      -2.412       1.591
Subject = Elia        2.2374      0.410      5.457      0.000       1.434       3.041
Subject = Minerva     1.5558      0.332      4.689      0.000       0.905       2.206
TimeSinceFeeding      0.0238      0.019      1.237      0.216      -0.014       0.062
=====================================================================================
```

## Location results for 120 interval

### Logistic Generalized Linear Model, 120s, First 2/3s of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:               AtFeeder   No. Observations:                  551
Model:                          Logit   Df Residuals:                      546
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.1108
Time:                        13:15:16   Log-Likelihood:                -291.13
converged:                       True   LL-Null:                       -327.39
Covariance Type:            nonrobust   LLR p-value:                 6.637e-15
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept             0.5298      0.277      1.915      0.055      -0.012       1.072
Subject = Citrine     0.0713      0.257      0.278      0.781      -0.432       0.574
Subject = Elia        1.0073      0.244      4.122      0.000       0.528       1.486
Subject = Minerva     2.7981      0.488      5.737      0.000       1.842       3.754
TimeSinceFeeding     -0.0061      0.005     -1.273      0.203      -0.015       0.003
=====================================================================================
```

### Logistic Generalized Linear Model, 120s, Last 1/3 of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:               AtFeeder   No. Observations:                  324
Model:                          Logit   Df Residuals:                      319
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.1681
Time:                        13:15:16   Log-Likelihood:                -168.54
converged:                       True   LL-Null:                       -202.59
Covariance Type:            nonrobust   LLR p-value:                 5.718e-14
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept            -2.7080      1.177     -2.301      0.021      -5.015      -0.402
Subject = Citrine     0.4246      0.339      1.253      0.210      -0.240       1.089
Subject = Elia        1.7337      0.330      5.254      0.000       1.087       2.380
Subject = Minerva     3.0733      0.565      5.437      0.000       1.965       4.181
TimeSinceFeeding      0.0228      0.011      2.095      0.036       0.001       0.044
=====================================================================================
```

## Location results for 180 interval

### Logistic Generalized Linear Model, 180s, First 2/3s of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:               AtFeeder   No. Observations:                  471
Model:                          Logit   Df Residuals:                      466
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.3545
Time:                        13:15:16   Log-Likelihood:                -186.10
converged:                       True   LL-Null:                       -288.31
Covariance Type:            nonrobust   LLR p-value:                 4.206e-43
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept            -0.3559      0.314     -1.132      0.258      -0.972       0.260
Subject = Citrine    -1.1455      0.307     -3.734      0.000      -1.747      -0.544
Subject = Elia        3.1282      0.487      6.423      0.000       2.174       4.083
Subject = Minerva     3.3490      0.536      6.250      0.000       2.299       4.399
TimeSinceFeeding      0.0058      0.004      1.525      0.127      -0.002       0.013
=====================================================================================
```

### Logistic Generalized Linear Model, 180s, Last 1/3 of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:               AtFeeder   No. Observations:                  229
Model:                          Logit   Df Residuals:                      224
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.2429
Time:                        13:15:16   Log-Likelihood:                -98.925
converged:                       True   LL-Null:                       -130.66
Covariance Type:            nonrobust   LLR p-value:                 5.395e-13
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept            -1.4151      1.653     -0.856      0.392      -4.654       1.824
Subject = Citrine     0.7878      0.408      1.930      0.054      -0.012       1.588
Subject = Elia        3.1168      0.639      4.881      0.000       1.865       4.368
Subject = Minerva     3.0679      0.640      4.797      0.000       1.814       4.321
TimeSinceFeeding      0.0079      0.010      0.764      0.445      -0.012       0.028
=====================================================================================
```

## Location results for 240 interval

### Logistic Generalized Linear Model, 240s, First 2/3s of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:               AtFeeder   No. Observations:                  531
Model:                          Logit   Df Residuals:                      526
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.2789
Time:                        13:15:16   Log-Likelihood:                -244.24
converged:                       True   LL-Null:                       -338.68
Covariance Type:            nonrobust   LLR p-value:                 9.200e-40
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept            -0.6434      0.269     -2.391      0.017      -1.171      -0.116
Subject = Citrine     0.7352      0.255      2.884      0.004       0.236       1.235
Subject = Elia        2.3926      0.287      8.349      0.000       1.831       2.954
Subject = Minerva     5.4468      1.020      5.343      0.000       3.449       7.445
TimeSinceFeeding     -0.0005      0.003     -0.193      0.847      -0.005       0.005
=====================================================================================
```

### Logistic Generalized Linear Model, 240s, Last 1/3 of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:               AtFeeder   No. Observations:                  280
Model:                          Logit   Df Residuals:                      275
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.2640
Time:                        13:15:16   Log-Likelihood:                -120.48
converged:                      False   LL-Null:                       -163.71
Covariance Type:            nonrobust   LLR p-value:                 7.454e-18
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept            -1.7117      1.239     -1.381      0.167      -4.141       0.717
Subject = Citrine     0.5725      0.340      1.685      0.092      -0.093       1.239
Subject = Elia        2.6130      0.480      5.443      0.000       1.672       3.554
Subject = Minerva    18.2171   1104.644      0.016      0.987   -2146.845    2183.279
TimeSinceFeeding      0.0077      0.006      1.287      0.198      -0.004       0.019
=====================================================================================

Possibly complete quasi-separation: A fraction 0.20 of observations can be
perfectly predicted. This might indicate that there is complete
quasi-separation. In this case some parameters will not be identified.
```

## Location results for 300 interval

### Logistic Generalized Linear Model, 300s, First 2/3s of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:               AtFeeder   No. Observations:                  536
Model:                          Logit   Df Residuals:                      531
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.1970
Time:                        13:15:16   Log-Likelihood:                -266.37
converged:                       True   LL-Null:                       -331.71
Covariance Type:            nonrobust   LLR p-value:                 2.773e-27
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept             0.2237      0.255      0.876      0.381      -0.277       0.724
Subject = Citrine     0.0965      0.251      0.385      0.700      -0.395       0.588
Subject = Elia        3.2052      0.421      7.611      0.000       2.380       4.031
Subject = Minerva     1.5448      0.286      5.400      0.000       0.984       2.105
TimeSinceFeeding     -0.0033      0.002     -1.762      0.078      -0.007       0.000
=====================================================================================
```

### Logistic Generalized Linear Model, 300s, Last 1/3 of interval

```
                           Logit Regression Results                           
==============================================================================
Dep. Variable:               AtFeeder   No. Observations:                  283
Model:                          Logit   Df Residuals:                      278
Method:                           MLE   Df Model:                            4
Date:                Fri, 05 Sep 2025   Pseudo R-squ.:                  0.3280
Time:                        13:15:16   Log-Likelihood:                -128.20
converged:                       True   LL-Null:                       -190.78
Covariance Type:            nonrobust   LLR p-value:                 4.194e-26
=====================================================================================
                        coef    std err          z      P>|z|      [0.025      0.975]
-------------------------------------------------------------------------------------
Intercept            -3.1388      1.340     -2.342      0.019      -5.765      -0.512
Subject = Citrine    -1.4327      0.412     -3.480      0.001      -2.240      -0.626
Subject = Elia        3.5266      0.636      5.543      0.000       2.280       4.773
Subject = Minerva     1.0834      0.370      2.929      0.003       0.358       1.808
TimeSinceFeeding      0.0116      0.005      2.241      0.025       0.001       0.022
=====================================================================================
```

# Water Consumption Statistics

## Linear Model for Bernie

```
                            OLS Regression Results                            
==============================================================================
Dep. Variable:                session   R-squared:                       0.378
Model:                            OLS   Adj. R-squared:                  0.366
Method:                 Least Squares   F-statistic:                     32.80
Date:                Fri, 05 Sep 2025   Prob (F-statistic):           4.65e-07
Time:                        13:15:16   Log-Likelihood:                -278.81
No. Observations:                  56   AIC:                             561.6
Df Residuals:                      54   BIC:                             565.7
Df Model:                           1                                         
Covariance Type:            nonrobust                                         
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept     69.5556      8.785      7.918      0.000      51.944      87.168
Days           1.0586      0.185      5.727      0.000       0.688       1.429
==============================================================================
Omnibus:                        1.685   Durbin-Watson:                   2.197
Prob(Omnibus):                  0.431   Jarque-Bera (JB):                0.944
Skew:                          -0.027   Prob(JB):                        0.624
Kurtosis:                       3.634   Cond. No.                         87.3
==============================================================================

Notes:
[1] Standard Errors assume correct specification of covariance matrix.
```

## Linear Model for Citrine

```
                            OLS Regression Results                            
==============================================================================
Dep. Variable:                session   R-squared:                       0.000
Model:                            OLS   Adj. R-squared:                 -0.019
Method:                 Least Squares   F-statistic:                   0.01175
Date:                Fri, 05 Sep 2025   Prob (F-statistic):              0.914
Time:                        13:15:16   Log-Likelihood:                -243.68
No. Observations:                  53   AIC:                             491.4
Df Residuals:                      51   BIC:                             495.3
Df Model:                           1                                         
Covariance Type:            nonrobust                                         
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept     82.7957      6.237     13.276      0.000      70.275      95.316
Days          -0.0150      0.138     -0.108      0.914      -0.293       0.263
==============================================================================
Omnibus:                        7.717   Durbin-Watson:                   1.350
Prob(Omnibus):                  0.021   Jarque-Bera (JB):                7.990
Skew:                          -0.589   Prob(JB):                       0.0184
Kurtosis:                       4.494   Cond. No.                         83.6
==============================================================================

Notes:
[1] Standard Errors assume correct specification of covariance matrix.
```

## Linear Model for Elia

```
                            OLS Regression Results                            
==============================================================================
Dep. Variable:                session   R-squared:                       0.273
Model:                            OLS   Adj. R-squared:                  0.261
Method:                 Least Squares   F-statistic:                     23.98
Date:                Fri, 05 Sep 2025   Prob (F-statistic):           6.92e-06
Time:                        13:15:16   Log-Likelihood:                -330.74
No. Observations:                  66   AIC:                             665.5
Df Residuals:                      64   BIC:                             669.9
Df Model:                           1                                         
Covariance Type:            nonrobust                                         
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept    110.0446      8.727     12.610      0.000      92.611     127.478
Days           0.7822      0.160      4.897      0.000       0.463       1.101
==============================================================================
Omnibus:                       17.497   Durbin-Watson:                   2.039
Prob(Omnibus):                  0.000   Jarque-Bera (JB):               29.742
Skew:                          -0.911   Prob(JB):                     3.48e-07
Kurtosis:                       5.737   Cond. No.                         105.
==============================================================================

Notes:
[1] Standard Errors assume correct specification of covariance matrix.
```

## Linear Model for Minerva

```
                            OLS Regression Results                            
==============================================================================
Dep. Variable:                session   R-squared:                       0.072
Model:                            OLS   Adj. R-squared:                  0.056
Method:                 Least Squares   F-statistic:                     4.418
Date:                Fri, 05 Sep 2025   Prob (F-statistic):             0.0400
Time:                        13:15:16   Log-Likelihood:                -282.10
No. Observations:                  59   AIC:                             568.2
Df Residuals:                      57   BIC:                             572.4
Df Model:                           1                                         
Covariance Type:            nonrobust                                         
==============================================================================
                 coef    std err          t      P>|t|      [0.025      0.975]
------------------------------------------------------------------------------
Intercept    129.4832      7.543     17.165      0.000     114.378     144.589
Days          -0.3243      0.154     -2.102      0.040      -0.633      -0.015
==============================================================================
Omnibus:                       10.271   Durbin-Watson:                   1.880
Prob(Omnibus):                  0.006   Jarque-Bera (JB):               15.433
Skew:                           0.554   Prob(JB):                     0.000445
Kurtosis:                       5.247   Cond. No.                         96.5
==============================================================================

Notes:
[1] Standard Errors assume correct specification of covariance matrix.
```

## Kolmogorov–Smirnov Tests

| Subject   | Comparison                | KS statistics   | p-value   |
|:----------|:--------------------------|:----------------|:----------|
| Bernie    | Interval 60s vs Baseline  | ks = 0.821      | p = 0.004 |
| Bernie    | Interval 120s vs Baseline | ks = 0.786      | p < 0.001 |
| Bernie    | Interval 180s vs Baseline | ks = 0.536      | p = 0.094 |
| Bernie    | Interval 240s vs Baseline | ks = 0.336      | p = 0.574 |
| Bernie    | Interval 300s vs Baseline | ks = 0.500      | p = 0.371 |
| Citrine   | Interval 60s vs Baseline  | ks = 0.430      | p = 0.281 |
| Citrine   | Interval 120s vs Baseline | ks = 0.811      | p = 0.005 |
| Citrine   | Interval 180s vs Baseline | ks = 0.698      | p = 0.011 |
| Citrine   | Interval 240s vs Baseline | ks = 0.811      | p = 0.089 |
| Citrine   | Interval 300s vs Baseline | ks = 0.962      | p < 0.001 |
| Elia      | Interval 60s vs Baseline  | ks = 0.970      | p < 0.001 |
| Elia      | Interval 120s vs Baseline | ks = 0.770      | p = 0.002 |
| Elia      | Interval 180s vs Baseline | ks = 0.818      | p < 0.001 |
| Elia      | Interval 240s vs Baseline | ks = 0.970      | p < 0.001 |
| Elia      | Interval 300s vs Baseline | ks = 0.770      | p = 0.002 |
| Minerva   | Interval 60s vs Baseline  | ks = 0.949      | p < 0.001 |
| Minerva   | Interval 120s vs Baseline | ks = 0.546      | p = 0.083 |
| Minerva   | Interval 180s vs Baseline | ks = 0.376      | p = 0.426 |
| Minerva   | Interval 240s vs Baseline | ks = 0.407      | p = 0.339 |
| Minerva   | Interval 300s vs Baseline | ks = 0.563      | p = 0.067 |